#include <Servo.h>

// ------------------- Pin Definitions -------------------
const int LDR_LEFT_PIN  = A0;   // Left LDR analog input
const int LDR_RIGHT_PIN = A1;   // Right LDR analog input
const int SERVO_PIN     = 9;    // Servo control pin (PWM)

// ------------------- Tunable Parameters -----------------
const int TOLERANCE   = 20;     // Allowed difference before moving (reduces jitter)
const int STEP_ANGLE  = 1;      // Degrees to move per correction step
const int MIN_ANGLE   = 10;     // Minimum mechanical limit of servo
const int MAX_ANGLE   = 170;    // Maximum mechanical limit of servo
const int LOOP_DELAY  = 30;     // Delay (ms) between control loop iterations

Servo panelServo;                // Servo object controlling panel orientation
int currentAngle = 90;           // Track current servo angle (start centered)

void setup() {
  Serial.begin(9600);            // For debugging / monitoring LDR values
  panelServo.attach(SERVO_PIN);  // Attach servo to its control pin
  panelServo.write(currentAngle);// Move to initial centered position
  delay(500);                    // Allow servo to settle at startup
}

void loop() {
  int leftValue  = analogRead(LDR_LEFT_PIN);   // Read left LDR (0-1023)
  int rightValue = analogRead(LDR_RIGHT_PIN);  // Read right LDR (0-1023)
  int difference = leftValue - rightValue;     // Compute imbalance

  Serial.print("Left: "); Serial.print(leftValue);
  Serial.print("  Right: "); Serial.print(rightValue);
  Serial.print("  Diff: "); Serial.println(difference);

  if (abs(difference) > TOLERANCE) {
    if (difference > 0) {
      // More light on the LEFT side -> rotate panel LEFT (decrease angle)
      currentAngle = currentAngle - STEP_ANGLE;
    } else {
      // More light on the RIGHT side -> rotate panel RIGHT (increase angle)
      currentAngle = currentAngle + STEP_ANGLE;
    }

    // Constrain angle within safe mechanical limits
    currentAngle = constrain(currentAngle, MIN_ANGLE, MAX_ANGLE);
    panelServo.write(currentAngle);
  }

  delay(LOOP_DELAY);   // Small delay before next reading/correction
}
