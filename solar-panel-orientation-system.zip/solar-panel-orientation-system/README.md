# Advanced Solar Panel Orientation System Using Arduino UNO

An automatic single-axis solar tracking system built with an Arduino UNO, two LDR (Light Dependent Resistor) sensors, and a servo motor. The system continuously detects the direction of maximum sunlight intensity and rotates a small photovoltaic panel to face it, improving energy capture compared to a fixed panel.

## Project Overview

Fixed solar panels only face the sun optimally for a short period around solar noon. This project builds a low-cost closed-loop tracking system that:
- Reads light intensity from two LDR sensors mounted on either side of the panel
- Compares the readings to determine which side has more sunlight
- Drives a servo motor to rotate the panel toward the brighter side
- Repeats continuously throughout the day

## Hardware Components

| Component | Quantity | Notes |
|---|---|---|
| Arduino UNO (R3) | 1 | ATmega328P, main controller |
| LDR (Photoresistor) | 2 | Light sensing, mounted left/right |
| Servo Motor (SG90) | 1 | Rotates the panel |
| Solar Panel (5V–6V, small) | 1 | Payload / output |
| Breadboard (830 point) | 1 | Prototyping |
| Resistors (10kΩ) | 2 | Voltage-divider with each LDR |
| Jumper wires | ~20 | Connections |

## Circuit Diagram

![Circuit Diagram](images/circuit_diagram.png)

**Pin connections:**

| Component | Arduino UNO Pin |
|---|---|
| Left LDR (voltage-divider midpoint) | A0 |
| Right LDR (voltage-divider midpoint) | A1 |
| Servo signal wire | D9 (PWM) |
| Servo VCC | 5V |
| Servo GND | GND |

## Block Diagram

![Block Diagram](images/block_diagram.png)

## Control Algorithm (Flowchart)

![Flowchart](images/flowchart.png)

## How It Works

1. Both LDRs continuously report a voltage proportional to incident light intensity.
2. The Arduino compares the left and right readings.
3. If the difference exceeds a tolerance threshold, the servo steps the panel toward the brighter side.
4. The angle is constrained within safe mechanical limits (10°–170°).
5. This repeats every ~30 ms, allowing the panel to track the sun's movement across the sky.

## Getting Started

### Requirements
- Arduino IDE (1.8.x or 2.x)
- `Servo.h` library (comes bundled with Arduino IDE)
- USB cable + Arduino UNO board

### Wiring
1. Connect each LDR in series with a 10kΩ resistor between 5V and GND (voltage divider).
2. Connect the midpoint of the left divider to A0, and the right divider to A1.
3. Connect the servo's signal wire to pin 9, VCC to 5V, and GND to GND.
4. Mount the solar panel on the servo's rotating arm, with the two LDRs fixed on either side of it (a small opaque divider between them improves directionality).

### Uploading the Code
1. Open `solar_tracker.ino` in the Arduino IDE.
2. Select **Tools → Board → Arduino UNO** and the correct COM port.
3. Click **Upload**.
4. Open the Serial Monitor (9600 baud) to view live LDR readings while testing.

## Tunable Parameters (in code)

| Parameter | Default | Purpose |
|---|---|---|
| `TOLERANCE` | 20 | Minimum LDR difference before moving (reduces jitter) |
| `STEP_ANGLE` | 1 | Degrees moved per correction step |
| `MIN_ANGLE` / `MAX_ANGLE` | 10 / 170 | Safe mechanical rotation limits |
| `LOOP_DELAY` | 30 ms | Delay between control loop iterations |

## Results

Testing showed the tracking panel consistently produced equal or higher voltage output than a fixed reference panel throughout the day, with the largest improvement (~25–37%) observed in the early morning and late afternoon.

## Future Improvements

- Dual-axis tracking (add elevation control)
- IoT monitoring via ESP8266/ESP32
- Data logging to SD card or cloud
- Battery storage with charge controller
- Weatherproof enclosure

## Author

**Selvakumar K**
Department of Electronics and Communication Engineering
VSB Engineering College, Karur

## License

This project is open-source under the MIT License.
